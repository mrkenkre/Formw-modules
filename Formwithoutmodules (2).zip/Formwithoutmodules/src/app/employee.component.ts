export class Employee {
  empNo:number;
  empName:string;
  salary:number;
  dept:string;
 constructor(empNo:number,empName:string,salary:number,dept:string){
     this.empNo=empNo;
     this.empName=empName;
     this.salary=salary;
     this.dept=dept;
 }
}